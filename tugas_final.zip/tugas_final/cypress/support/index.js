import 'cypress-mochawesome-reporter';
import 'cypress-mochawesome-reporter/register';
