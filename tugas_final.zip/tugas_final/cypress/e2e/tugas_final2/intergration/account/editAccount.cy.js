import EditAccountPage from '../../pages/EditAccountPage';
import userData from '../../fixtures/userData.json';

describe('Edit Account Information Test', () => {
  before(() => {
    // Login terlebih dahulu
    cy.visit('https://magento.softwaretestingboard.com/customer/account/login/');
    cy.get('#email').type(userData.validUser.email);
    cy.get('#pass').type(userData.validUser.password);
    cy.get('#send2').click();
  });

  it('should edit account information successfully', () => {
    EditAccountPage.visit();
    EditAccountPage.editInformation('Johnathan', 'Doe Jr.', 'johnathan.doe@example.com', userData.validUser.password);
    EditAccountPage.assertEditSuccessMessage();
  });
});
