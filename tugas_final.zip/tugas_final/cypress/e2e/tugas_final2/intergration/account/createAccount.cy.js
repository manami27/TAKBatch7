import CreateAccountPage from '../../pages/CreateAccountPage';
import userData from '../../fixtures/userData.json';

describe('Create Account Test', () => {
  beforeEach(() => {
    CreateAccountPage.visit();
  });

  it('should create an account with valid data', () => {
    CreateAccountPage.fillFirstName(userData.validUser.firstname);
    CreateAccountPage.fillLastName(userData.validUser.lastname);
    CreateAccountPage.fillEmail(userData.validUser.email);
    CreateAccountPage.fillPassword(userData.validUser.password);
    CreateAccountPage.fillPasswordConfirmation(userData.validUser.password);
    CreateAccountPage.submit();
    CreateAccountPage.assertSuccessMessage();
  });

  it('should show error for existing email', () => {
    CreateAccountPage.fillFirstName('Jane');
    CreateAccountPage.fillLastName('Doe');
    CreateAccountPage.fillEmail(userData.validUser.email); // Email yang sudah ada
    CreateAccountPage.fillPassword(userData.validUser.password);
    CreateAccountPage.fillPasswordConfirmation(userData.validUser.password);
    CreateAccountPage.submit();
    CreateAccountPage.assertEmailErrorMessage();
  });
});
