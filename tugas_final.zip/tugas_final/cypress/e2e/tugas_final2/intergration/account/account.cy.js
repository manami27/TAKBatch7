import LoginPage from '../../pages/LoginPage';
import userData from '../../fixtures/userData.json';

describe('Login Test', () => {
  beforeEach(() => {
    LoginPage.visit();
  });

  it('should login with valid credentials', () => {
    LoginPage.fillEmail(userData.validUser.email);
    LoginPage.fillPassword(userData.validUser.password);
    LoginPage.submit();
    LoginPage.assertSuccessfulLogin();
  });

  it('should show error for invalid credentials', () => {
    LoginPage.fillEmail(userData.invalidUser.email);
    LoginPage.fillPassword(userData.invalidUser.password);
    LoginPage.submit();
    LoginPage.assertErrorMessage('Invalid login or password.');
  });
});
