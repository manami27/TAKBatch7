// cypress/pages/ProductPage.js
class ProductPage {
    visitCategory(category) {
      cy.visit(`/catalog/category/view/id/${category}`);
    }
  
    addToCart(productIndex) {
      cy.get(`.product-item`).eq(productIndex).find('.action.tocart').click();
    }
  
    verifyProductAdded() {
      cy.get('.message-success').should('be.visible').and('contain', 'You added');
    }
  }
  
  export default ProductPage;
  