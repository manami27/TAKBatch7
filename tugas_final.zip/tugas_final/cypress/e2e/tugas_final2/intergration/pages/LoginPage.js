class LoginPage {
  visit() {
    cy.visit('https://magento.softwaretestingboard.com/customer/account/login/');
  }

  fillEmail(email) {
    cy.get('#email').type(email);
  }

  fillPassword(password) {
    cy.get('#pass').type(password);
  }

  submit() {
    cy.get('#send2').click();
  }

  assertErrorMessage(message) {
    cy.get('.message-error').should('contain', message);
  }

  assertSuccessfulLogin() {
    cy.url().should('include', '/customer/account');
    cy.get('.customer-welcome').should('be.visible');
  }
}

export default new LoginPage();
