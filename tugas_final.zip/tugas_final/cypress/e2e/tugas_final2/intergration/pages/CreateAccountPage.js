class CreateAccountPage {
  visit() {
    cy.visit('https://magento.softwaretestingboard.com/customer/account/create/');
  }

  fillFirstName(firstname) {
    cy.get('#firstname').type(firstname);
  }

  fillLastName(lastname) {
    cy.get('#lastname').type(lastname);
  }

  fillEmail(email) {
    cy.get('#email_address').type(email);
  }

  fillPassword(password) {
    cy.get('#password').type(password);
  }

  fillPasswordConfirmation(password) {
    cy.get('#password-confirmation').type(password);
  }

  submit() {
    cy.get('form#form-validate').submit();
  }

  assertSuccessMessage() {
    cy.get('.message-success').should('contain', 'Thank you for registering with Main Website Store.');
  }

  assertEmailErrorMessage() {
    cy.get('.message-error').should('contain', 'There is already an account with this email address.');
  }
}

export default new CreateAccountPage();
