class EditAccountPage {
    visit() {
      cy.get('.customer-welcome').click();
      cy.contains('My Account').click();
    }
  
    editInformation(firstname, lastname, email, currentPassword) {
      cy.get('.block-dashboard-info > .block-content > .box > .box-actions > .edit > span').click();
      cy.get('#firstname').clear().type(firstname);
      cy.get('#lastname').clear().type(lastname);
      cy.get('#change-email').click();
      cy.get('#email').clear().type(email);
      cy.get('#current-password').type(currentPassword);
      cy.get('#form-validate > .actions-toolbar > div.primary > .action').click();
    }
  
    assertEditSuccessMessage() {
      cy.get('.message-success').should('contain', 'You saved the account information.');
    }
  }
  
  export default new EditAccountPage();
  