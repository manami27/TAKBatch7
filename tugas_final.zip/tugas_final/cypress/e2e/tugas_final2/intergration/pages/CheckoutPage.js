// cypress/pages/CheckoutPage.js
class CheckoutPage {
    visit() {
      cy.visit('/checkout/cart/');
    }
  
    proceedToCheckout() {
      cy.get('.action.checkout').click();
    }
  
    verifyCheckoutPage() {
      cy.url().should('include', '/checkout');
    }
  }
  
  export default CheckoutPage;
  