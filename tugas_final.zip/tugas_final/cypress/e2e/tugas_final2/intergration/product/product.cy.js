describe('Product Selection and Checkout Test', () => {
  before(() => {
    // Login terlebih dahulu
    cy.visit('https://magento.softwaretestingboard.com/customer/account/login/');
    cy.get('#email').type('johnathan.doe@example.com'); // Email yang telah diubah
    cy.get('#pass').type('SecureP@ssword1');
    cy.get('#send2').click();
  });

  it('should add product to cart and proceed to checkout', () => {
    cy.visit('https://magento.softwaretestingboard.com/');
    
    // Pilih produk (misalnya produk pertama)
    cy.get('.product-item').first().click();
    cy.get('.action.tocart').click();

    // Verifikasi produk ada di cart
    cy.get('.minicart-wrapper').click();
    cy.get('.minicart-content-wrapper').should('contain', 'Product Name'); // Ganti dengan nama produk yang sesuai

    // Klik proceed to checkout
    cy.get('.action.checkout').click();

    // Verifikasi kita di halaman checkout
    cy.url().should('include', '/checkout');
  });
});
