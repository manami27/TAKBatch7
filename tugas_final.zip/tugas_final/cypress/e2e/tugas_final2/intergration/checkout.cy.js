// cypress/integration/checkout.spec.js
import CheckoutPage from './pages/CheckoutPage';

const checkoutPage = new CheckoutPage();

describe('Checkout Tests', () => {
  beforeEach(() => {
    cy.fixture('userData').as('userData');
  });

  it('Positive Test: Proceed to checkout successfully', function() {
    checkoutPage.visit();
    checkoutPage.proceedToCheckout();
    checkoutPage.verifyCheckoutPage();
  });

  it('Negative Test: Try to proceed without items in cart', function() {
    // Pastikan keranjang kosong
    checkoutPage.visit();
    cy.get('.cart-empty').should('be.visible'); // Verifikasi keranjang kosong
  });
});
