describe('Data-Driven Test for Login and Edit Account', () => {
  beforeEach(() => {
    // Memuat data dari fixture untuk login dan edit akun
    cy.fixture('loginData1').as('loginData1');
    cy.fixture('editAccountData').as('editAccountData');
  });

  it('Should test login functionality and edit account with multiple data sets', function() {
    // Iterasi melalui setiap set data login dan edit akun
    this.loginData1.forEach((user, index) => {
      const editData = this.editAccountData[index]; // Ambil data edit akun sesuai dengan urutan login

      // Kunjungi halaman utama
      cy.visit('https://magento.softwaretestingboard.com/');

      // Klik link Login
      cy.get('.panel > .header > .authorization-link > a').click();

      // Masukkan email dan password dari data login
      cy.get('#email').type(user.email);
      cy.get('#pass').type(user.password);
      
      // Klik tombol login
      cy.get('#send2').click();

      // Tunggu hingga elemen yang ada di halaman akun muncul untuk memastikan login berhasil
      cy.get('.customer-welcome', { timeout: 30000 }).should('be.visible'); // Tunggu hingga elemen muncul

      // // Sekarang verifikasi URL
      // cy.url().should('include', '/customer/account');

      // Klik ikon user untuk menampilkan opsi My Account
      cy.get('.customer-welcome').first().click({ force: true });

      // Klik link "My Account"
      cy.contains('My Account').click({ force: true });

      // Tunggu hingga halaman My Account selesai dimuat
      cy.url().should('include', '/customer/account');

      // Klik tombol untuk mengedit informasi akun
      cy.get('.block-dashboard-info > .block-content > .box > .box-actions > .edit > span').click();

      // Isi form edit dengan data baru dari fixture editAccountData
      cy.get('#firstname').clear().type(editData.firstname);
      cy.get('#lastname').clear().type(editData.lastname);
      
      // Klik untuk mengubah email
      cy.get('#change-email').click(); 

      // Masukkan email baru
      cy.get('#email').clear().type(editData.email);
      
      // Masukkan password saat ini
      cy.get('#current-password').type(editData.currentPassword);

      // Klik tombol Save untuk menyimpan perubahan
      cy.get('#form-validate > .actions-toolbar > div.primary > .action').click();

    
    });
  });
});
