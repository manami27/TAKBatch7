describe('Login and Edit Account Tests', () => {
    const validUser = {
      email: 'valid.user@example.com',
      password: 'Valid-Password123',
      firstname: 'ValidFirst',
      lastname: 'ValidLast',
      newEmail: 'new.valid.user@example.com'
    };
  
    const invalidUser = {
      email: 'invalid.user@example.com',
      password: 'Invalid-Password'
    };
  
    it('Positive case: Login and edit account information', () => {
      cy.visit('https://magento.softwaretestingboard.com/');
      cy.get('.authorization-link > a').click();
      cy.get('#email').type(validUser.email);
      cy.get('#pass').type(validUser.password);
      cy.get('#send2').click();
  
      cy.get('.customer-welcome').should('be.visible').click();
      cy.contains('My Account').click();
      cy.get('.edit > span').click();
  
      cy.get('#firstname').clear().type(validUser.firstname);
      cy.get('#lastname').clear().type(validUser.lastname);
      cy.get('#change-email').click();
      cy.get('#email').clear().type(validUser.newEmail);
      cy.get('#current-password').type(validUser.password);
      cy.get('#form-validate .action').click();
  
      cy.get('.message-success').should('be.visible').and('contain', 'You saved the account information.');
    });
  
    it('Negative case: Show error for invalid login', () => {
      cy.visit('https://magento.softwaretestingboard.com/');
      cy.get('.authorization-link > a').click();
      cy.get('#email').type(invalidUser.email);
      cy.get('#pass').type(invalidUser.password);
      cy.get('#send2').click();
  
      cy.get('.message-error').should('be.visible').and('contain', 'Invalid login or password.');
    });
  });
  