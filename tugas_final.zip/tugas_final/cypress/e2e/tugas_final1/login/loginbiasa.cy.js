describe('Positive and Negative Test Cases for Login', () => {
    beforeEach(() => {
        // Memuat data dari fixture
        cy.fixture('loginData1').as('loginData1');
      });
    
  
    it('Should login successfully with valid credentials', () => {
      // Kunjungi halaman utama
      cy.visit('https://magento.softwaretestingboard.com/');
  
      // Klik link Login
      cy.get('.panel > .header > .authorization-link > a').click();
  
      // Masukkan email dan password yang valid
      cy.get('#email').type('ryan.ananda@example.com');  // Ganti dengan email yang valid
      cy.get('#pass').type('Val1d-p@ssword');  // Ganti dengan password yang valid
      
      // Klik tombol login
      cy.get('#send2').click();
  
      
      // Logout setelah login berhasil untuk persiapan tes berikutnya
      cy.get('.panel > .header > .authorization-link > a').click();
    });
  
    it('Should show an error when trying to login with invalid credentials', () => {
      // Kunjungi halaman utama
      cy.visit('https://magento.softwaretestingboard.com/');
  
      // Klik link Login
      cy.get('.panel > .header > .authorization-link > a').click();
  
      // Masukkan email dan password yang tidak valid
      cy.get('#email').type('invalid-email@example.com'); // Ganti dengan email yang tidak valid
      cy.get('#pass').type('invalidPassword'); // Ganti dengan password yang tidak valid
      
      // Klik tombol login
      cy.get('#send2').click();
  
      // Verifikasi bahwa pesan error muncul
      cy.get('.message-error', { timeout: 10000 }).should('be.visible')
        .and('contain', 'Invalid login or password.');
    });
  });
  