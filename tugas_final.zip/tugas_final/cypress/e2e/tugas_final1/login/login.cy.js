describe('Data-Driven Test for Login', () => {
  beforeEach(() => {
    // Memuat data dari fixture
    cy.fixture('loginData').as('loginData');
  });

  it('Should test login functionality with multiple data sets', function() {
    // Iterasi melalui setiap set data di fixture loginData
    this.loginData.forEach((user) => {
      cy.visit('https://magento.softwaretestingboard.com/');

      // Klik link Login
      cy.get('.panel > .header > .authorization-link > a').click();

      // Masukkan email dan password dari data yang berbeda
      cy.get('#email').type(user.email);
      cy.get('#pass').type(user.password);
      
      // Klik tombol login
      cy.get('#send2').click();

      // Verifikasi hasil berdasarkan expectedResult
      if (user.expectedResult === 'success') {
        // Jika login sukses, kita cari elemen "My Account" yang hanya muncul saat login berhasil
        cy.contains('My Account').should('be.visible');
      } else if (user.expectedResult === 'error') {
        // Jika login gagal, kita cari pesan error
        cy.get('.message-error').should('be.visible')
          .and('contain', 'Invalid login or password.');
      }
      
      // Logout setelah login berhasil untuk menghindari masalah dengan pengujian berikutnya
      if (user.expectedResult === 'success') {
        cy.get('.panel > .header > .authorization-link > a').click();
      }
    });

    // Update JSON data jika diperlukan
    cy.writeFile('cypress/fixtures/loginData.json', this.loginData);
  });
});
