describe('Data-Driven Test for Create Account', () => {
  beforeEach(() => {
    // Memuat data dari fixture
    cy.fixture('accountData').as('accountData');
  });

  it('Should create accounts with multiple data sets', function() {
    // Iterasi melalui setiap set data akun di fixture
    this.accountData.forEach((account, index) => {
      cy.visit('https://magento.softwaretestingboard.com/customer/account/create/');

      // Mengisi form pendaftaran
      cy.get('#firstname').type(account.firstname);
      cy.get('#lastname').type(account.lastname);
      cy.get('#email_address').type(account.email);
      cy.get('#password').type(account.password);
      cy.get('#password-confirmation').type(account.password);

      // Klik tombol "Create an Account"
      cy.get('#form-validate > .actions-toolbar > div.primary > .action > span').click();

      // Tunggu sebentar untuk memverifikasi hasil
      cy.wait(2000); // Tunggu selama 2 detik

      // Verifikasi bahwa pendaftaran berhasil
      if (account.expectedResult === 'success') {
        // Jika diharapkan berhasil, periksa pesan sukses
        cy.contains('Thank you for registering with Main Website Store', { timeout: 10000 }).should('be.visible');
        // Menandai hasil pendaftaran
        this.accountData[index].result = 'success'; 
      } else if (account.expectedResult === 'error') {
        // Jika diharapkan gagal, periksa pesan error
        cy.contains('There is a customer with the email address', { timeout: 10000 }).should('be.visible');
        // Menandai hasil pendaftaran
        this.accountData[index].result = 'error'; 
      }

      // Mengklik link "Sign In" jika pendaftaran berhasil
      if (this.accountData[index].result === 'success') {
        cy.get(':nth-child(2) > .customer-welcome > .customer-menu > .header > .authorization-link > a').click();
      }

      // Tunggu sebentar sebelum melanjutkan ke iterasi berikutnya
      cy.wait(2000); // Tunggu selama 2 detik
    });

    // Setelah semua tes, simpan hasil yang diperbarui ke file JSON
    cy.writeFile('cypress/fixtures/accountData.json', this.accountData);
  });
});
