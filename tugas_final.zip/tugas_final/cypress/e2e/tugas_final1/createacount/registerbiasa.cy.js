describe('Positive and Negative Test Cases for Create Account', () => {
  
    it('Should create an account successfully with valid data', () => {
      // Kunjungi halaman pendaftaran
      cy.visit('https://magento.softwaretestingboard.com/customer/account/create/');
  
      // Mengisi form pendaftaran dengan data valid
      cy.get('#firstname').type('Ryan43');
      cy.get('#lastname').type('Ananda43');
      cy.get('#email_address').type('valid04-email@example.com'); // Email yang valid
      cy.get('#password').type('v@l1d-Password');
      cy.get('#password-confirmation').type('v@l1d-Password');
  
      // Klik tombol "Create an Account"
      cy.get('#form-validate > .actions-toolbar > div.primary > .action > span').click();
  
      // Verifikasi bahwa pendaftaran berhasil
      cy.contains('Thank you for registering with Main Website Store', { timeout: 10000 }).should('be.visible');
    });
  
    it('Should show an error when trying to register with an existing email', () => {
      // Kunjungi halaman pendaftaran
      cy.visit('https://magento.softwaretestingboard.com/customer/account/create/');
  
      // Mengisi form pendaftaran dengan data yang sudah ada
      cy.get('#firstname').type('John');
      cy.get('#lastname').type('Doe');
      cy.get('#email_address').type('valid-email@example.com'); // Email yang sudah terdaftar
      cy.get('#password').type('anotherPassword!');
      cy.get('#password-confirmation').type('anotherPassword!');
  
      // Klik tombol "Create an Account"
      cy.get('#form-validate > .actions-toolbar > div.primary > .action > span').click();
  
      // Verifikasi bahwa muncul pesan error
      cy.contains('There is a customer with the email address', { timeout: 10000 }).should('be.visible');
    });
  });
  